# HLS Scraper Research

**Date:** 2026-10-16
**Goal:** Build independent HLS URL scraper for Arenaflix (not dependent on Watchout2025/api)

## Test IDs
- 1007757 (Swapped)
- 550 (Fight Club)
- 27205 (Inception)

---

## Approach 1: Simple HTTP Scraping of Videasy

**Status:** ❌ FAILED

**Tested:**
- `https://player.videasy.net/movie/{tmdbId}` - Cloudflare protection blocks datacenter IPs
- Simple `requests.get()` returns Cloudflare challenge page, no m3u8 URLs

**Conclusion:** Videasy uses Cloudflare Turnstile. Cannot bypass with simple HTTP.

---

## Approach 2: embed.su API

**Status:** ❌ BLOCKED (from datacenter)

**Method** (from vidsrc-bypass library):
1. Fetch `https://embed.su/embed/movie/{id}`
2. Extract `window.vConfig = JSON.parse(atob(...))` from HTML
3. Base64 decode to get video details with server hashes
4. Fetch stream URL using hash

**Test Result:** Connection failed (HTTP 000) - blocked from datacenter IPs.

**Note:** This would likely work from residential IPs or GitHub Actions.

---

## Approach 3: vidsrc.rip API

**Status:** ❌ BLOCKED (from datacenter)

**Method** (from vidsrc-bypass library):
1. Fetch `https://vidsrc.rip/embed/movie/{id}`
2. Extract `window.config = {...}` from HTML
3. Generate VRF token using XOR + base64 (key from page)
4. Call `/api/source/{server}/{id}?vrf={token}`

**Test Result:** Connection failed (HTTP 000) - blocked from datacenter IPs.

---

## Approach 4: vidlink.pro API

**Status:** ⚠️ ACCESSIBLE BUT RETURNS NULL

**Method** (from vidsrc-bypass library):
1. Encrypt TMDB ID with AES-256-CBC (hardcoded key: `2de6e6ea13a9df9503b11a6117fd7e51941e04a0c223dfeacfe8a1dbb6c52783`)
2. Format: `{iv_hex}:{encrypted_hex}`, then base64 encode
3. Call `https://vidlink.pro/api/b/movie/{b64}`

**Test Result:**
- HTTP 200 (accessible!)
- Response: `null` for both 550 and 786892 (test ID from repo)
- Library last updated 2024 - API likely changed or dead

**Conclusion:** Endpoint accessible but not returning data. May need investigation.

---

## Approach 5: enc-dec.app Decryption Service

**Status:** ✅ WORKS (but needs input data)

**Test:**
- `POST https://enc-dec.app/api/dec-videasy` with `{"text":"test","id":"550"}`
- Response: `{"status":400,"error":"Expected body: text, id, seed"}`

**How it works:**
1. Get encrypted data from Videasy API (requires auth token)
2. POST to enc-dec.app with `{text, id, seed}`
3. Returns decrypted HLS URLs

**Blocker:** Step 1 requires Videasy API access which needs Cloudflare Turnstile bypass.

**Reference:** https://github.com/smy778/EncDecEndpoints

---

## Approach 6: Headless Browser (RECOMMENDED)

**Status:** ✅ PROVEN TO WORK (by others)

### rb-extractor (RottenBrains)
- **Repo:** https://github.com/timdobras/rottenbrains/blob/HEAD/rb-extractor/README.md
- **Method:** Loads Videasy embed in real Chromium (headed under xvfb), sniffs network for `.m3u8`
- **API:** `GET /extract?type=movie&id=27205` → `{url, headers, subtitles}`
- **Cache:** 25 min in-memory (URLs are short-lived)
- **Deploy:** Docker with Chromium + xvfb

### vidsrc-scraper (DivineChile)
- **Repo:** https://github.com/DivineChile/vidsrc-scraper
- **Method:** Playwright + Chromium, scrapes VidSrc domains
- **API:** `GET /extract?tmdb_id=550&type=movie`
- **Targets:** vidsrc.xyz, vidsrc.in, vidsrc.pm, vidsrc.net
- **Deploy:** Railway/Docker

### streambert (akekulip)
- **Method:** Chrome loads Videasy "rcp" page, mints token, sniffs m3u8
- **Flow:** `POST /api/extract/vidsrc` → Chrome → `{m3u8, referer}` → proxy → play

**Why this works:**
- Real browser passes Cloudflare protection
- JavaScript executes, player loads, network requests visible
- Can intercept m3u8 URLs from network traffic

**For GitHub Actions:**
- Runners have Chrome pre-installed
- Playwright can be installed via npm
- Can run on schedule (cron)
- No server to maintain 24/7

---

## Approach 7: VidSrc Direct (vidsrc.pm, vidsrc.to)

**Status:** ⚠️ PARTIAL (pages accessible, no m3u8 in static HTML)

**Tested:**
- `vidsrc.pm/embed/movie/550` → HTTP 200 ✅
- `vidsrc.to/embed/movie/550` → HTTP 200 ✅
- `vidsrc.xyz`, `vidsrc.in`, `vidsrc.net` → Connection failed ❌

**Finding:** Pages load but m3u8 URLs are loaded via JavaScript (not in static HTML).
Requires headless browser OR reverse-engineering the JS API calls.

---

## RPMShare

**Status:** ❌ NOT RELEVANT

RPMShare is a file hosting service (Telegram → hosting bridge), not a movie streaming API.
Mentioned in VidOut page as "Powered by RPMShare and Videasy" but it's for file storage,
not TMDB-based movie streaming.

---

## Summary

| Approach | Status | Notes |
|----------|--------|-------|
| Simple HTTP (Videasy) | ❌ Failed | Cloudflare block |
| embed.su | ❌ Blocked | Datacenter IP block |
| vidsrc.rip | ❌ Blocked | Datacenter IP block |
| vidlink.pro API | ⚠️ Null | Accessible but no data |
| enc-dec.app | ✅ Works | Needs Videasy encrypted data |
| Headless Browser | ✅ Proven | Best option for GitHub Actions |
| VidSrc direct | ⚠️ Partial | Needs JS execution |

## Recommendation

**Use Headless Browser via GitHub Actions:**

1. Create Playwright-based scraper
2. Target: Videasy (primary), VidSrc domains (fallback)
3. Run daily via GitHub Actions cron
4. Save URLs to `hls/movie/{id}` files
5. Player fetches from our repo with fallback to Watchout2025

**Why GitHub Actions:**
- Free (2000 min/month)
- Chrome pre-installed on runners
- No server maintenance
- Automated daily runs
- Git-based storage (like Watchout2025)

**Next Steps:**
1. Build Playwright scraper script
2. Test locally (if Chromium available) or directly in Actions
3. Set up daily cron workflow
4. Update player to use our repo as primary, Watchout2025 as fallback
