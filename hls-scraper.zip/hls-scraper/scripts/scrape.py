#!/usr/bin/env python3
"""
Arenaflix HLS Scraper - Experimental
Tries to extract HLS URLs from Videasy/player sources.
"""
import os
import sys
import json
import requests

# Test movie IDs to scrape (popular movies)
TEST_MOVIES = [
    1007757,  # Swapped
    550,      # Fight Club
    27205,    # Inception
    558,      # Spider-Man 2
    969681,   # From earlier tests
]

BASE_DIR = os.path.join(os.path.dirname(__file__), '..', 'hls')

def scrape_videasy_embed(tmdb_id):
    """
    Try to get HLS URL from Videasy embed page.
    This is the hard part - Videasy has Cloudflare protection.
    """
    # Try the public embed URL
    url = f"https://player.videasy.net/movie/{tmdb_id}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://player.videasy.net/',
    }
    try:
        r = requests.get(url, headers=headers, timeout=15)
        # Look for m3u8 URLs in the page
        import re
        m3u8_urls = re.findall(r'https://[^"\']*\.m3u8[^"\']*', r.text)
        if m3u8_urls:
            return m3u8_urls[0]
    except Exception as e:
        print(f"  Videasy embed failed: {e}", file=sys.stderr)
    return None

def scrape_movie(tmdb_id):
    """Scrape HLS URL for a movie."""
    print(f"Scraping movie {tmdb_id}...")

    # Try Videasy
    url = scrape_videasy_embed(tmdb_id)
    if url:
        print(f"  Got: {url[:80]}...")
        return url

    print(f"  No URL found for {tmdb_id}")
    return None

def main():
    os.makedirs(os.path.join(BASE_DIR, 'movie'), exist_ok=True)

    success = 0
    for tmdb_id in TEST_MOVIES:
        url = scrape_movie(tmdb_id)
        if url:
            path = os.path.join(BASE_DIR, 'movie', str(tmdb_id))
            with open(path, 'w') as f:
                f.write(url)
            success += 1

    print(f"\nDone: {success}/{len(TEST_MOVIES)} scraped")
    return 0 if success > 0 else 1

if __name__ == '__main__':
    sys.exit(main())
